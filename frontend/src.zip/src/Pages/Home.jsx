import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";
import Inicio from "../Components/home";


function Home() {
  return (
    <>
        <Navbar />
        <Inicio />
        <Footer />
    </>
  );
}

export default Home;