import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";
import TiempoLaboral from "../Components/Tiempo_laboral";

function Tiempo() {
  return (
    <div>
      <Navbar />
      <TiempoLaboral />
      <Footer />
    </div>
  );
}

export default Tiempo;